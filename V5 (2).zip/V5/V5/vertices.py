class vertices(object):
    """description of class"""



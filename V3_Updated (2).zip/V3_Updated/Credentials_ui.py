# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Credentials.ui'
##
## Created by: Qt User Interface Compiler version 6.6.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QLabel, QLineEdit,
    QMainWindow, QPushButton, QSizePolicy, QSpacerItem,
    QStackedWidget, QVBoxLayout, QWidget)
import resources_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(400, 480)
        font = QFont()
        font.setPointSize(12)
        font.setBold(True)
        MainWindow.setFont(font)
        MainWindow.setStyleSheet(u"\n"
"#signUpPage,#signInPage{\n"
"	background-color: qlineargradient(spread:pad, x1:0.54, y1:0.597182, x2:0, y2:1, stop:0 rgba(38, 80, 115, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}\n"
"#label_3, #label_4, #label_1, #label_2,#label_5{\n"
"	\n"
"	color: rgb(255, 255, 255);\n"
"}\n"
"#password_2, #username_2, #password_3, #username_3{\n"
"	color: rgba(255,255,255,230);\n"
"	border: none;\n"
"	background-color: rgb(0,0,0,0);\n"
"	border-bottom: 2px solid rgba(105,118,132,255);\n"
"	padding-bottom: 7px\n"
"}\n"
"#LoginBtn, #SignUpBtn2_2{\n"
"	color: rgb(255, 255, 255);\n"
"	\n"
"	background-color: rgb(170, 0, 0);\n"
"}\n"
"\n"
"#SignUpBtn, #LoginBtn2_2{\n"
"		\n"
"	\n"
"	color: rgb(255, 51, 0);\n"
"}\n"
"#showPassBtn_2, #showPassBtn{\n"
"	\n"
"	background-color:transparent;\n"
"	\n"
"}\n"
"\n"
"              ")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.stackedWidget = QStackedWidget(self.centralwidget)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.signInPage = QWidget()
        self.signInPage.setObjectName(u"signInPage")
        self.verticalLayout_4 = QVBoxLayout(self.signInPage)
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.widget_5 = QWidget(self.signInPage)
        self.widget_5.setObjectName(u"widget_5")
        self.horizontalLayout_9 = QHBoxLayout(self.widget_5)
        self.horizontalLayout_9.setSpacing(0)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.horizontalLayout_9.setContentsMargins(0, 0, 0, 0)
        self.label_5 = QLabel(self.widget_5)
        self.label_5.setObjectName(u"label_5")
        font1 = QFont()
        font1.setPointSize(30)
        self.label_5.setFont(font1)

        self.horizontalLayout_9.addWidget(self.label_5)


        self.verticalLayout_4.addWidget(self.widget_5, 0, Qt.AlignHCenter)

        self.widget_9 = QWidget(self.signInPage)
        self.widget_9.setObjectName(u"widget_9")
        self.widget_9.setMinimumSize(QSize(300, 120))
        self.horizontalLayout_10 = QHBoxLayout(self.widget_9)
        self.horizontalLayout_10.setSpacing(0)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.horizontalLayout_10.setContentsMargins(0, 0, 0, 0)
        self.horizontalSpacer_7 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_10.addItem(self.horizontalSpacer_7)

        self.username_2 = QLineEdit(self.widget_9)
        self.username_2.setObjectName(u"username_2")
        self.username_2.setMinimumSize(QSize(232, 30))
        self.username_2.setMaximumSize(QSize(250, 30))

        self.horizontalLayout_10.addWidget(self.username_2)

        self.horizontalSpacer_8 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_10.addItem(self.horizontalSpacer_8)


        self.verticalLayout_4.addWidget(self.widget_9, 0, Qt.AlignHCenter|Qt.AlignVCenter)

        self.widget_10 = QWidget(self.signInPage)
        self.widget_10.setObjectName(u"widget_10")
        self.widget_10.setMinimumSize(QSize(300, 120))
        self.horizontalLayout_3 = QHBoxLayout(self.widget_10)
        self.horizontalLayout_3.setSpacing(0)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.horizontalSpacer_9 = QSpacerItem(25, 20, QSizePolicy.Maximum, QSizePolicy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer_9)

        self.password_2 = QLineEdit(self.widget_10)
        self.password_2.setObjectName(u"password_2")
        sizePolicy = QSizePolicy(QSizePolicy.Maximum, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.password_2.sizePolicy().hasHeightForWidth())
        self.password_2.setSizePolicy(sizePolicy)
        self.password_2.setMinimumSize(QSize(232, 30))
        self.password_2.setMaximumSize(QSize(300, 30))

        self.horizontalLayout_3.addWidget(self.password_2)

        self.showPassBtn_2 = QPushButton(self.widget_10)
        self.showPassBtn_2.setObjectName(u"showPassBtn_2")
        sizePolicy1 = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.showPassBtn_2.sizePolicy().hasHeightForWidth())
        self.showPassBtn_2.setSizePolicy(sizePolicy1)
        self.showPassBtn_2.setMaximumSize(QSize(30, 30))
        font2 = QFont()
        font2.setPointSize(8)
        self.showPassBtn_2.setFont(font2)
        icon = QIcon()
        icon.addFile(u":/icons/icons/eye-off.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.showPassBtn_2.setIcon(icon)
        self.showPassBtn_2.setIconSize(QSize(24, 24))
        self.showPassBtn_2.setCheckable(True)

        self.horizontalLayout_3.addWidget(self.showPassBtn_2)


        self.verticalLayout_4.addWidget(self.widget_10, 0, Qt.AlignHCenter|Qt.AlignVCenter)

        self.widget_11 = QWidget(self.signInPage)
        self.widget_11.setObjectName(u"widget_11")
        self.LoginBtn = QPushButton(self.widget_11)
        self.LoginBtn.setObjectName(u"LoginBtn")
        self.LoginBtn.setGeometry(QRect(100, 20, 201, 31))
        self.LoginBtn.setFont(font)
        self.label_1 = QLabel(self.widget_11)
        self.label_1.setObjectName(u"label_1")
        self.label_1.setGeometry(QRect(100, 60, 141, 21))
        font3 = QFont()
        font3.setFamilies([u"Arial"])
        self.label_1.setFont(font3)
        self.SignUpBtn = QPushButton(self.widget_11)
        self.SignUpBtn.setObjectName(u"SignUpBtn")
        self.SignUpBtn.setGeometry(QRect(230, 60, 81, 21))
        font4 = QFont()
        font4.setPointSize(8)
        font4.setBold(True)
        self.SignUpBtn.setFont(font4)
        self.SignUpBtn.setFlat(True)

        self.verticalLayout_4.addWidget(self.widget_11)

        self.stackedWidget.addWidget(self.signInPage)
        self.signUpPage = QWidget()
        self.signUpPage.setObjectName(u"signUpPage")
        self.verticalLayout_2 = QVBoxLayout(self.signUpPage)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.widget = QWidget(self.signUpPage)
        self.widget.setObjectName(u"widget")
        self.horizontalLayout = QHBoxLayout(self.widget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.label_4 = QLabel(self.widget)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setFont(font1)

        self.horizontalLayout.addWidget(self.label_4, 0, Qt.AlignHCenter)


        self.verticalLayout_2.addWidget(self.widget)

        self.widget_2 = QWidget(self.signUpPage)
        self.widget_2.setObjectName(u"widget_2")
        self.widget_2.setMinimumSize(QSize(300, 120))
        self.horizontalLayout_4 = QHBoxLayout(self.widget_2)
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_2)

        self.username_3 = QLineEdit(self.widget_2)
        self.username_3.setObjectName(u"username_3")
        self.username_3.setMinimumSize(QSize(232, 30))
        self.username_3.setMaximumSize(QSize(250, 30))

        self.horizontalLayout_4.addWidget(self.username_3)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer)


        self.verticalLayout_2.addWidget(self.widget_2, 0, Qt.AlignHCenter|Qt.AlignVCenter)

        self.widget_3 = QWidget(self.signUpPage)
        self.widget_3.setObjectName(u"widget_3")
        sizePolicy2 = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.widget_3.sizePolicy().hasHeightForWidth())
        self.widget_3.setSizePolicy(sizePolicy2)
        self.widget_3.setMinimumSize(QSize(300, 120))
        self.widget_3.setMaximumSize(QSize(800, 16777215))
        self.horizontalLayout_5 = QHBoxLayout(self.widget_3)
        self.horizontalLayout_5.setSpacing(0)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.horizontalSpacer_3 = QSpacerItem(25, 20, QSizePolicy.Maximum, QSizePolicy.Minimum)

        self.horizontalLayout_5.addItem(self.horizontalSpacer_3)

        self.password_3 = QLineEdit(self.widget_3)
        self.password_3.setObjectName(u"password_3")
        sizePolicy.setHeightForWidth(self.password_3.sizePolicy().hasHeightForWidth())
        self.password_3.setSizePolicy(sizePolicy)
        self.password_3.setMinimumSize(QSize(232, 30))
        self.password_3.setMaximumSize(QSize(300, 30))

        self.horizontalLayout_5.addWidget(self.password_3, 0, Qt.AlignHCenter)

        self.showPassBtn = QPushButton(self.widget_3)
        self.showPassBtn.setObjectName(u"showPassBtn")
        sizePolicy1.setHeightForWidth(self.showPassBtn.sizePolicy().hasHeightForWidth())
        self.showPassBtn.setSizePolicy(sizePolicy1)
        self.showPassBtn.setMaximumSize(QSize(30, 30))
        self.showPassBtn.setFont(font2)
        self.showPassBtn.setIcon(icon)
        self.showPassBtn.setIconSize(QSize(24, 24))
        self.showPassBtn.setCheckable(True)

        self.horizontalLayout_5.addWidget(self.showPassBtn)


        self.verticalLayout_2.addWidget(self.widget_3, 0, Qt.AlignHCenter|Qt.AlignVCenter)

        self.widget_4 = QWidget(self.signUpPage)
        self.widget_4.setObjectName(u"widget_4")
        self.SignUpBtn2_2 = QPushButton(self.widget_4)
        self.SignUpBtn2_2.setObjectName(u"SignUpBtn2_2")
        self.SignUpBtn2_2.setGeometry(QRect(100, 20, 201, 31))
        self.SignUpBtn2_2.setFont(font)
        self.label_2 = QLabel(self.widget_4)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(100, 60, 141, 21))
        self.label_2.setFont(font3)
        self.LoginBtn2_2 = QPushButton(self.widget_4)
        self.LoginBtn2_2.setObjectName(u"LoginBtn2_2")
        self.LoginBtn2_2.setGeometry(QRect(230, 60, 81, 21))
        self.LoginBtn2_2.setFont(font4)
        self.LoginBtn2_2.setFlat(True)

        self.verticalLayout_2.addWidget(self.widget_4)

        self.stackedWidget.addWidget(self.signUpPage)

        self.verticalLayout.addWidget(self.stackedWidget)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        self.stackedWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"Log In", None))
        self.username_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Username", None))
        self.password_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Password", None))
        self.showPassBtn_2.setText("")
        self.LoginBtn.setText(QCoreApplication.translate("MainWindow", u"Log In", None))
        self.label_1.setText(QCoreApplication.translate("MainWindow", u"Already have an account?", None))
        self.SignUpBtn.setText(QCoreApplication.translate("MainWindow", u"Sign Up", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"Sign Up", None))
        self.username_3.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Username", None))
        self.password_3.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Password", None))
        self.showPassBtn.setText("")
        self.SignUpBtn2_2.setText(QCoreApplication.translate("MainWindow", u"Sign Up", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Already have an account?", None))
        self.LoginBtn2_2.setText(QCoreApplication.translate("MainWindow", u"Log In", None))
    # retranslateUi


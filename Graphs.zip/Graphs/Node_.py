
class Node_(object):
    def __init__(self, data):
        self.neighbours=linklist
        self.data = data
        self.next = None
        self.previous=None
    #def __init__(self,data):
     #   self.neighbours=None
      #  self.data = data
       # self.next = None
        #self.previous=None
    
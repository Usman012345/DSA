class Node(object):
   def __init__(self,key,data):
       self.key=key
       self.data=data

   
        


